# android-otpless-demo
repo for android sdk demo

<p align="right">
  <img src="https://github.com/otpless-tech/otpless-android-sdk/blob/main/otpless.svg" height="20"/>
</p>
<p align="center">
  <img src="https://github.com/otpless-tech/otpless-android-sdk/blob/main/loginPage.png" height="400"/>
</p>

# OTPLESS android SDK
[![](https://jitpack.io/v/otpless-tech/otpless-android-sdk.svg)](https://jitpack.io/#otpless-tech/otpless-android-sdk)



## Installation

You can checkout the complete [installation guide here](https://otpless.com/platforms/android)

## Author

[OTPLESS](https://otpless.com), developer@otpless.com



## License
